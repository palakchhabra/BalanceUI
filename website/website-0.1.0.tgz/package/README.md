# BalanceUI Website

A modern, SEO-optimized website for the BalanceUI component library built with Next.js.

## Features

- ✅ **SEO Optimized**: Complete metadata, sitemap, robots.txt, and structured data
- ✅ **Modern Design**: Beautiful, responsive UI using BalanceUI components
- ✅ **Fast Performance**: Built with Next.js 16 for optimal performance
- ✅ **Accessible**: Following WCAG guidelines for accessibility
- ✅ **TypeScript**: Full type safety throughout
- ✅ **Dark Mode**: Automatic dark mode support

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Install dependencies:

```bash
npm install
```

2. Run the development server:

```bash
npm run dev
```

3. Open [http://localhost:3000](http://localhost:3000) in your browser.

## Project Structure

```
app/
  ├── layout.tsx          # Root layout with SEO metadata
  ├── page.tsx            # Homepage
  ├── components/         # Component documentation pages
  ├── docs/               # Documentation pages
  ├── examples/           # Example pages
  ├── sitemap.ts          # Dynamic sitemap generation
  ├── robots.ts           # Robots.txt configuration
  └── manifest.ts         # PWA manifest
components/
  ├── Navigation.tsx      # Main navigation component
  ├── Footer.tsx          # Footer component
  └── StructuredData.tsx  # SEO structured data
```

## SEO Features

- **Metadata**: Comprehensive meta tags for all pages
- **Open Graph**: Social media sharing optimization
- **Twitter Cards**: Twitter sharing optimization
- **Sitemap**: Auto-generated sitemap.xml
- **Robots.txt**: Search engine crawler configuration
- **Structured Data**: JSON-LD schema markup
- **Canonical URLs**: Proper canonical URL handling

## Building for Production

```bash
npm run build
npm start
```

## Local Package Usage

This website uses the local BalanceUI package. To update the package:

1. Build the BalanceUI package from the root directory:
```bash
cd ../..
npm run build
```

2. The package will be automatically picked up from `balanceui-core-1.0.0.tgz`

## Pages

- **Home** (`/`): Landing page with hero, features, and quick start
- **Components** (`/components`): Browse all available components
- **Component Details** (`/components/[name]`): Individual component documentation
- **Documentation** (`/docs`): Getting started and guides
- **Examples** (`/examples`): Real-world usage examples

## Customization

### Themes

BalanceUI themes are imported in `app/layout.tsx`. Change the theme by updating the import:

```tsx
import "@balanceui/core/theme/sky-white.css";
```

Available themes:
- sky-white
- forest-cream
- mint-charcoal
- plum-ash
- rose-charcoal
- sand-ocean
- slate-lime
- clay-graphite
- ink-bone
- black-white

## License

Same as BalanceUI core package.
